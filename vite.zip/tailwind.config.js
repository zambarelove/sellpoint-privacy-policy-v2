module.exports = {
  content: ["*"],
  theme: {
    extend: { 
      fontSize: {
        '10xl': ['100px', { lineHeight: '1' }],
      },
      /*

      spacing: {
        13: '130px',
      },
      fontSize: {
        '10xl': ['18rem', { lineHeight: '1' }],
      },
      colors: {
       

        'hotpink': {
          100: '#fff0f7',
          200: '#ffd2e8',
          300: '#ffc3e1',
          400: '#ffb4d9',
          500: '#ffa5d2',
          600: '#ff96ca',
          700: '#ff87c3',
          800: '#ff78bb',
          900: '#FF69B4',
        }

      } */
    },
  },
  plugins: [],
}
